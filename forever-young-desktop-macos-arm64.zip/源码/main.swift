import AppKit
import AVFoundation

let cellWidth = 192
let cellHeight = 208
let petSize = NSSize(width: 230.4, height: 249.6)
func nowMilliseconds() -> Double { ProcessInfo.processInfo.systemUptime * 1000 }
func restartOfficialVoice(_ player: AVAudioPlayer) -> Bool {
    player.stop()
    player.currentTime = 0
    return player.play()
}

struct PetAssets {
    let frames: [[NSImage]]
    let voiceURL: URL

    init(resources: URL) throws {
        enum AssetError: Error { case invalidAtlas, invalidFrame }
        let atlasURL = resources.appendingPathComponent("spritesheet.png")
        guard let source = CGImageSourceCreateWithURL(atlasURL as CFURL, nil),
              let atlas = CGImageSourceCreateImageAtIndex(source, 0, nil),
              atlas.width == 1536, atlas.height == 2288 else { throw AssetError.invalidAtlas }
        var images: [[NSImage]] = []
        let counts = PetRuntime.durations.map { $0.count } + [8, 8]
        for row in 0..<11 {
            var rowImages: [NSImage] = []
            for column in 0..<counts[row] {
                guard let crop = atlas.cropping(to: CGRect(x: column * cellWidth, y: row * cellHeight,
                                                         width: cellWidth, height: cellHeight)) else {
                    throw AssetError.invalidFrame
                }
                rowImages.append(NSImage(cgImage: crop, size: NSSize(width: cellWidth, height: cellHeight)))
            }
            images.append(rowImages)
        }
        frames = images
        voiceURL = resources.appendingPathComponent("official-voice.mp3")
    }
}

final class PetPanel: NSPanel {
    override var canBecomeKey: Bool { false }
    override var canBecomeMain: Bool { false }
}

final class PetView: NSView {
    var image: NSImage? { didSet { needsDisplay = true } }
    var greet: (() -> Void)?
    var moved: (() -> Void)?
    private var pressPoint: NSPoint?
    private var pressOrigin: NSPoint?
    private(set) var isDragging = false

    override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }
    override func draw(_ dirtyRect: NSRect) {
        NSColor.clear.setFill()
        dirtyRect.fill(using: .copy)
        image?.draw(in: bounds, from: .zero, operation: .sourceOver, fraction: 1,
                    respectFlipped: true, hints: [.interpolation: NSImageInterpolation.high])
    }
    override func mouseDown(with event: NSEvent) {
        pressPoint = window?.convertPoint(toScreen: event.locationInWindow)
        pressOrigin = window?.frame.origin
        isDragging = false
    }
    override func mouseDragged(with event: NSEvent) {
        guard let point = pressPoint, let origin = pressOrigin, let window = window else { return }
        let current = window.convertPoint(toScreen: event.locationInWindow)
        let dx = current.x - point.x
        let dy = current.y - point.y
        if hypot(dx, dy) > 4 { isDragging = true }
        if isDragging { window.setFrameOrigin(NSPoint(x: origin.x + dx, y: origin.y + dy)) }
    }
    override func mouseUp(with event: NSEvent) {
        guard pressPoint != nil else { return }
        if isDragging { moved?() } else { greet?() }
        pressPoint = nil
        pressOrigin = nil
        isDragging = false
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    private var panel: PetPanel!
    private var petView: PetView!
    private var assets: PetAssets!
    private var player: AVAudioPlayer!
    private var runtime = PetRuntime()
    private var timer: Timer?
    private var statusItem: NSStatusItem!
    private var latestFrame: SpriteFrame?
    private var voiceStarts = 0
    private var voiceError: String?
    private var diagnosticURL: URL?
    private var nextDiagnosticTime: Double = 0
    private let defaults = UserDefaults.standard

    func applicationDidFinishLaunching(_ notification: Notification) {
        do {
            guard let resources = Bundle.main.resourceURL else { throw CocoaError(.fileNoSuchFile) }
            assets = try PetAssets(resources: resources)
            player = try AVAudioPlayer(contentsOf: assets.voiceURL)
            player.numberOfLoops = 0
            player.prepareToPlay()
            if let index = CommandLine.arguments.firstIndex(of: "--diagnostics"),
               index + 1 < CommandLine.arguments.count {
                diagnosticURL = URL(fileURLWithPath: CommandLine.arguments[index + 1])
            }
            createPanel()
            createMenus()
            let timer = Timer(timeInterval: 1 / 60, target: self, selector: #selector(tick), userInfo: nil, repeats: true)
            RunLoop.main.add(timer, forMode: .common)
            self.timer = timer
            tick()
            panel.orderFrontRegardless()
        } catch {
            let alert = NSAlert()
            alert.messageText = "无法加载青春永驻桌宠"
            alert.informativeText = "请保留完整的 .app 文件。\n\(error.localizedDescription)"
            alert.runModal()
            NSApp.terminate(nil)
        }
    }

    private func createPanel() {
        let screen = NSScreen.main?.visibleFrame ?? NSRect(x: 0, y: 0, width: 1200, height: 800)
        var origin = NSPoint(x: screen.maxX - petSize.width - 40, y: screen.minY + 30)
        if let x = defaults.object(forKey: "petX") as? Double,
           let y = defaults.object(forKey: "petY") as? Double {
            let saved = NSRect(origin: NSPoint(x: x, y: y), size: petSize)
            if NSScreen.screens.contains(where: { $0.visibleFrame.intersects(saved) }) { origin = saved.origin }
        }
        panel = PetPanel(contentRect: NSRect(origin: origin, size: petSize),
                         styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        panel.title = "青春永驻 · 桌面交互版"
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.hasShadow = false
        panel.level = .floating
        panel.hidesOnDeactivate = false
        panel.isReleasedWhenClosed = false
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
        petView = PetView(frame: NSRect(origin: .zero, size: petSize))
        petView.toolTip = "点击问候 · 拖动移动 · 右键打开菜单"
        petView.setAccessibilityElement(true)
        petView.setAccessibilityRole(.button)
        petView.setAccessibilityLabel("青春永驻桌宠")
        petView.greet = { [weak self] in self?.greet() }
        petView.moved = { [weak self] in self?.rememberPosition() }
        panel.contentView = petView
    }

    private func createMenus() {
        let menu = NSMenu()
        let title = NSMenuItem(title: "フォーエバーヤング · 桌面版", action: nil, keyEquivalent: "")
        title.isEnabled = false
        menu.addItem(title)
        menu.addItem(.separator())
        addItem("鼠标互动", action: #selector(mouseMode), menu: menu)
        let actions = NSMenuItem(title: "动作预览", action: nil, keyEquivalent: "")
        let submenu = NSMenu()
        let names = ["待机", "向右跑", "向左跑", "挥手", "跳跃", "失落", "等待", "工作", "检查"]
        for (row, name) in names.enumerated() {
            let item = addItem(name, action: #selector(previewAction(_:)), menu: submenu)
            item.tag = row
        }
        actions.submenu = submenu
        menu.addItem(actions)
        addItem("播放官方问候", action: #selector(greet), menu: menu)
        menu.addItem(.separator())
        addItem("显示／隐藏桌宠", action: #selector(toggleVisibility), menu: menu)
        addItem("重置位置", action: #selector(resetPosition), menu: menu)
        addItem("退出桌宠", action: #selector(quit), menu: menu)
        petView.menu = menu
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        statusItem.button?.title = "🐎"
        statusItem.button?.toolTip = "青春永驻桌宠"
        statusItem.menu = menu
    }

    @discardableResult
    private func addItem(_ title: String, action: Selector, menu: NSMenu) -> NSMenuItem {
        let item = NSMenuItem(title: title, action: action, keyEquivalent: "")
        item.target = self
        menu.addItem(item)
        return item
    }

    @objc private func tick() {
        let now = nowMilliseconds()
        if panel.isVisible {
            let point = NSEvent.mouseLocation
            let rect = panel.frame
            // AppKit screen y goes upward; the sprite direction convention goes downward.
            runtime.point(dx: point.x - rect.midX, dy: rect.midY - point.y)
            runtime.hover(rect.contains(point), at: now, allowJump: !petView.isDragging)
            let frame = runtime.frame(at: now)
            if frame != latestFrame {
                petView.image = assets.frames[frame.row][frame.column]
                latestFrame = frame
                petView.setAccessibilityValue(frame.mode == "looking" ? "正在看着鼠标" :
                    frame.mode == "jumping" ? "正在跳跃" : frame.mode == "waving" ? "正在挥手" : "正在陪伴")
            }
        } else {
            runtime.hover(false, at: now)
        }
        if diagnosticURL != nil && now >= nextDiagnosticTime {
            writeDiagnostics()
            nextDiagnosticTime = now + 100
        }
    }

    @objc private func greet() {
        runtime.greet(at: nowMilliseconds())
        if restartOfficialVoice(player) {
            voiceStarts += 1
            voiceError = nil
        } else { voiceError = "Audio output failed to start" }
        tick()
    }
    @objc private func mouseMode() { runtime.preview(nil, at: nowMilliseconds()); tick() }
    @objc private func previewAction(_ sender: NSMenuItem) {
        runtime.preview(sender.tag, at: nowMilliseconds())
        tick()
    }
    @objc private func toggleVisibility() {
        if panel.isVisible { panel.orderOut(nil); player.stop() }
        else { panel.orderFrontRegardless(); tick() }
    }
    @objc private func resetPosition() {
        guard let rect = NSScreen.main?.visibleFrame else { return }
        panel.setFrameOrigin(NSPoint(x: rect.maxX - petSize.width - 40, y: rect.minY + 30))
        rememberPosition()
    }
    private func rememberPosition() {
        defaults.set(panel.frame.origin.x, forKey: "petX")
        defaults.set(panel.frame.origin.y, forKey: "petY")
    }
    @objc private func quit() { NSApp.terminate(nil) }
    func applicationWillTerminate(_ notification: Notification) {
        timer?.invalidate()
        player?.stop()
        if panel != nil { rememberPosition() }
    }

    // Opt-in local test evidence; normal launches do not create diagnostics files.
    private func writeDiagnostics() {
        guard let url = diagnosticURL else { return }
        let rect = panel.frame
        let report: [String: Any] = [
            "visible": panel.isVisible, "row": latestFrame?.row ?? -1, "column": latestFrame?.column ?? -1,
            "mode": latestFrame?.mode ?? "none", "lookIndex": runtime.lookIndex ?? -1,
            "jumpCount": runtime.jumpCount, "greetingCount": runtime.greetingCount,
            "voiceStarts": voiceStarts, "audioPlaying": player.isPlaying,
            "audioTime": player.currentTime, "audioDuration": player.duration, "voiceError": voiceError ?? "",
            "opaque": panel.isOpaque, "shadow": panel.hasShadow, "level": panel.level.rawValue,
            "frame": ["x": rect.origin.x, "y": rect.origin.y, "width": rect.width, "height": rect.height]
        ]
        if let data = try? JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys]) {
            try? data.write(to: url, options: .atomic)
        }
    }
}

// Test the real NSView mouse handlers with local events; never posts OS input events.
func runWindowEventChecks(resources: URL) throws -> [String] {
    enum WindowCheckError: Error { case failed(String) }
    func check(_ condition: Bool, _ label: String) throws {
        if !condition { throw WindowCheckError.failed(label) }
    }
    _ = NSApplication.shared
    let panel = PetPanel(contentRect: NSRect(x: 100, y: 100, width: 231, height: 250),
                         styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
    panel.isReleasedWhenClosed = false
    let view = PetView(frame: NSRect(x: 0, y: 0, width: 231, height: 250))
    panel.contentView = view
    let assets = try PetAssets(resources: resources)
    let player = try AVAudioPlayer(contentsOf: assets.voiceURL)
    var greetings = 0
    var moves = 0
    var played = false
    view.greet = { greetings += 1; played = restartOfficialVoice(player) }
    view.moved = { moves += 1 }
    func event(_ type: NSEvent.EventType, _ x: Double, _ y: Double) -> NSEvent {
        NSEvent.mouseEvent(with: type, location: NSPoint(x: x, y: y), modifierFlags: [],
                           timestamp: 0, windowNumber: panel.windowNumber, context: nil,
                           eventNumber: 0, clickCount: 1, pressure: 1)!
    }
    let initial = panel.frame.origin
    view.mouseDown(with: event(.leftMouseDown, 100, 100))
    view.mouseDragged(with: event(.leftMouseDragged, 130, 120))
    try check(abs(panel.frame.origin.x - initial.x - 30) < 0.1 &&
              abs(panel.frame.origin.y - initial.y - 20) < 0.1, "drag follows event screen coordinates")
    view.mouseUp(with: event(.leftMouseUp, 100, 100))
    try check(moves == 1 && greetings == 0, "drag release does not greet")
    view.mouseDown(with: event(.leftMouseDown, 100, 100))
    view.mouseUp(with: event(.leftMouseUp, 100, 100))
    try check(greetings == 1 && played, "click invokes greeting and actual audio playback")
    RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.16))
    try check(player.isPlaying && player.currentTime > 0.08, "audio clock advances on output device")
    view.mouseDown(with: event(.leftMouseDown, 100, 100))
    view.mouseUp(with: event(.leftMouseUp, 100, 100))
    try check(greetings == 2 && played && player.currentTime < 0.05, "repeat click restarts the same player")
    player.stop()
    panel.close()
    return ["NSView drag changes window origin", "drag release does not greet",
            "NSView click reaches official audio playback", "audio output clock advances",
            "repeat click rewinds the same player"]
}

if CommandLine.arguments.contains("--ui-self-test") {
    do {
        guard let resources = Bundle.main.resourceURL else { throw CocoaError(.fileNoSuchFile) }
        let checks = try runWindowEventChecks(resources: resources)
        let data = try JSONSerialization.data(withJSONObject: ["ok": true, "checks": checks],
                                              options: [.prettyPrinted, .sortedKeys])
        print(String(decoding: data, as: UTF8.self))
        exit(0)
    } catch {
        fputs("Window event test failed: \(error)\n", stderr)
        exit(1)
    }
}

if CommandLine.arguments.contains("--self-test") {
    do {
        var checks = try runInteractionChecks()
        guard let resources = Bundle.main.resourceURL else { throw CocoaError(.fileNoSuchFile) }
        let assets = try PetAssets(resources: resources)
        let player = try AVAudioPlayer(contentsOf: assets.voiceURL)
        guard assets.frames.map({ $0.count }).reduce(0, +) == 73, player.duration > 2.8, player.duration < 3.1 else {
            throw CocoaError(.fileReadCorruptFile)
        }
        checks.append("AppKit decodes all 73 PNG frame crops")
        checks.append("AVAudioPlayer decodes the unchanged official voice")
        let report: [String: Any] = ["ok": true, "checks": checks, "voiceDuration": player.duration]
        let data = try JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys])
        print(String(decoding: data, as: UTF8.self))
        exit(0)
    } catch {
        fputs("Self-test failed: \(error)\n", stderr)
        exit(1)
    }
}

let application = NSApplication.shared
if let identifier = Bundle.main.bundleIdentifier,
   NSRunningApplication.runningApplications(withBundleIdentifier: identifier).contains(where: {
       $0.processIdentifier != ProcessInfo.processInfo.processIdentifier
   }) { exit(0) }
application.setActivationPolicy(.accessory)
let delegate = AppDelegate()
application.delegate = delegate
application.run()
