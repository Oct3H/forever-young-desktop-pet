import Foundation

struct SpriteFrame: Equatable {
    let row: Int
    let column: Int
    let mode: String
}

struct PetRuntime {
    static let durations: [[Double]] = [
        [280, 110, 110, 140, 140, 320],
        [120, 120, 120, 120, 120, 120, 120, 220],
        [120, 120, 120, 120, 120, 120, 120, 220],
        [140, 140, 140, 280],
        [140, 140, 140, 140, 280],
        [140, 140, 140, 140, 140, 140, 140, 240],
        [150, 150, 150, 150, 150, 260],
        [120, 120, 120, 120, 120, 220],
        [150, 150, 150, 150, 150, 280]
    ]
    private(set) var inside = false
    private(set) var lookIndex: Int?
    private(set) var jumpCount = 0
    private(set) var greetingCount = 0
    private(set) var previewRow: Int?
    private var action: (row: Int, started: Double)?
    private var started: Double = 0

    // dx and dy use image coordinates: right is positive x, down is positive y.
    mutating func point(dx: Double, dy: Double) {
        guard hypot(dx, dy) > 1 else {
            lookIndex = nil
            return
        }
        let degrees = (atan2(dx, -dy) * 180 / .pi + 360).truncatingRemainder(dividingBy: 360)
        lookIndex = Int((degrees / 22.5).rounded()) % 16
    }

    mutating func hover(_ isInside: Bool, at now: Double, allowJump: Bool = true) {
        guard isInside != inside else { return }
        inside = isInside
        guard isInside, allowJump, previewRow == nil, action == nil else { return }
        action = (4, now)
        jumpCount += 1
    }

    mutating func greet(at now: Double) {
        previewRow = nil
        action = (3, now)
        greetingCount += 1
    }

    mutating func preview(_ row: Int?, at now: Double) {
        action = nil
        previewRow = row
        started = now
    }

    private func column(row: Int, elapsed: Double) -> Int {
        let timing = Self.durations[row]
        var offset = max(0, elapsed).truncatingRemainder(dividingBy: timing.reduce(0, +))
        for (index, duration) in timing.enumerated() {
            if offset < duration { return index }
            offset -= duration
        }
        return 0
    }

    mutating func frame(at now: Double) -> SpriteFrame {
        if let action = action {
            let elapsed = now - action.started
            if elapsed < Self.durations[action.row].reduce(0, +) {
                return SpriteFrame(row: action.row, column: column(row: action.row, elapsed: elapsed),
                                   mode: action.row == 4 ? "jumping" : "waving")
            }
            self.action = nil
            started = now
        }
        if let row = previewRow {
            return SpriteFrame(row: row, column: column(row: row, elapsed: now - started), mode: "preview")
        }
        if let look = lookIndex {
            return SpriteFrame(row: 9 + look / 8, column: look % 8, mode: "looking")
        }
        return SpriteFrame(row: 0, column: column(row: 0, elapsed: (now - started) / 6), mode: "idle")
    }
}

func runInteractionChecks() throws -> [String] {
    enum CheckFailure: Error { case failed(String) }
    func check(_ condition: Bool, _ label: String) throws {
        if !condition { throw CheckFailure.failed(label) }
    }
    var pet = PetRuntime()
    for index in 0..<16 {
        let radians = Double(index) * .pi / 8
        pet.point(dx: sin(radians) * 300, dy: -cos(radians) * 300)
        try check(pet.lookIndex == index, "direction \(index)")
        let frame = pet.frame(at: 0)
        try check(frame.row == 9 + index / 8 && frame.column == index % 8, "atlas selection \(index)")
    }
    pet.point(dx: 0, dy: 0)
    try check(pet.frame(at: 0).mode == "idle", "center dead zone")
    pet.point(dx: 300, dy: 0)
    pet.hover(true, at: 0)
    try check(pet.frame(at: 300).row == 4 && pet.frame(at: 300).column == 2, "airborne jump frame")
    for time in stride(from: 0.0, through: 10_000, by: 10) {
        pet.hover(true, at: time)
        _ = pet.frame(at: time)
    }
    try check(pet.jumpCount == 1 && pet.frame(at: 10_000).mode == "looking", "one jump during stationary hover")
    pet.hover(false, at: 10_001)
    pet.hover(true, at: 10_002)
    try check(pet.jumpCount == 2 && pet.frame(at: 10_003).mode == "jumping", "leave and re-enter")
    pet.greet(at: 10_004)
    try check(pet.frame(at: 10_005).mode == "waving", "click interrupts jump")
    pet.point(dx: -300, dy: 0)
    try check(pet.frame(at: 10_705).row == 10 && pet.frame(at: 10_705).column == 4, "latest mouse direction resumes")
    pet.greet(at: 11_000)
    pet.greet(at: 11_100)
    try check(pet.greetingCount == 3 && pet.frame(at: 11_101).column == 0, "repeat click restarts greeting")
    pet.hover(false, at: 12_000)
    pet.hover(true, at: 12_001, allowJump: false)
    try check(pet.jumpCount == 2, "drag does not trigger jump")
    for row in 0..<9 {
        pet.preview(row, at: 20_000)
        try check(pet.frame(at: 20_010).row == row, "preview row \(row)")
    }
    pet.preview(nil, at: 21_000)
    try check(pet.frame(at: 21_001).mode == "looking", "return to mouse interaction")
    return ["16 screen directions and atlas cells", "center dead zone", "10 seconds of hover has one jump",
            "re-entry starts a new jump", "click preempts jump", "gaze resumes at latest pointer",
            "repeat click restarts greeting", "drag does not trigger jump", "all nine original actions"]
}
