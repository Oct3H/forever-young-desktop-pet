package org.foreveryoungpet.bridge;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.intellij.execution.ProgramRunnerUtil;
import com.intellij.execution.RunManager;
import com.intellij.execution.RunnerAndConfigurationSettings;
import com.intellij.execution.executors.DefaultRunExecutor;
import com.intellij.execution.process.ProcessHandler;
import com.intellij.execution.runners.ExecutionEnvironment;
import com.intellij.openapi.Disposable;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.util.Disposer;
import com.intellij.ide.util.PropertiesComponent;
import com.intellij.openapi.ui.popup.JBPopupFactory;
import javax.swing.DefaultListCellRenderer;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.*;
import java.util.concurrent.*;

public final class PetBridge implements Disposable {
  private static final Map<Project,PetBridge> INSTANCES=new WeakHashMap<>();
  public static synchronized PetBridge get(Project project) {return INSTANCES.computeIfAbsent(project,PetBridge::new);}
  private final Project project;
  private final String instance=UUID.randomUUID().toString();
  private final Path root=Paths.get(System.getProperty("user.home"),"Library","Application Support","ForeverYoungPet","Bridge");
  private final Gson gson=new Gson();
  private final ScheduledExecutorService timer=Executors.newSingleThreadScheduledExecutor(r->{Thread t=new Thread(r,"ForeverYoung local bridge");t.setDaemon(true);return t;});
  private final Map<Long,ProcessHandler> active=new HashMap<>();
  private final Set<String> seen=new HashSet<>();
  private String state="idle",runID="",title;
  private int sequence=0;
  private volatile boolean disposed=false;
  private PetBridge(Project project) {
    this.project=project;title=project.getName();Disposer.register(project,this);
    try {for(String folder:List.of("events","commands","acks")){Path p=root.resolve(folder);Files.createDirectories(p);Files.setPosixFilePermissions(p,PosixFilePermissions.fromString("rwx------"));}}
    catch(Exception ignored){return;}
    publish();timer.scheduleAtFixedRate(this::publish,10,10,TimeUnit.SECONDS);timer.scheduleWithFixedDelay(this::poll,500,500,TimeUnit.MILLISECONDS);
  }
  synchronized void started(ExecutionEnvironment environment,ProcessHandler handler) {
    active.put(environment.getExecutionId(),handler);state="working";runID=Long.toString(environment.getExecutionId());title=environment.getRunProfile().getName();publish();
  }
  synchronized void ended(ExecutionEnvironment environment,ProcessHandler handler,int code) {
    active.remove(environment.getExecutionId());state=code==0?"completed":code==130||code==143?"interrupted":"failed";
    runID=Long.toString(environment.getExecutionId());title=environment.getRunProfile().getName();publish();
  }
  private void write(String folder,String name,Object data)throws Exception {
    Path target=root.resolve(folder).resolve(name+".json"),temp=root.resolve(folder).resolve(name+".tmp");
    Files.writeString(temp,gson.toJson(data));Files.setPosixFilePermissions(temp,PosixFilePermissions.fromString("rw-------"));Files.move(temp,target,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
  }
  private synchronized void publish() {
    if(disposed)return;
    try {Map<String,Object> event=new LinkedHashMap<>();event.put("version",1);event.put("source","pycharm");event.put("instance",instance);event.put("sequence",++sequence);event.put("sentAt",System.currentTimeMillis());event.put("state",state);event.put("runID",runID);event.put("title",title.length()>500?title.substring(0,500):title);event.put("project",Objects.toString(project.getBasePath(),""));event.put("activeCount",active.size());event.put("actions",List.of("run","chooseRun","test","stop"));write("events",instance,event);}
    catch(Exception ignored){} // No project output or credentials are logged.
  }
  private void poll() {
    if(disposed||project.isDisposed())return;
    try(DirectoryStream<Path> files=Files.newDirectoryStream(root.resolve("commands"),instance+"-*.json")) {
      int count=0;
      for(Path file:files) {
        if(++count>100)break;
        if(Files.isSymbolicLink(file)||!Files.isRegularFile(file)||Files.size(file)>4096)continue;
        try {
        JsonObject value=gson.fromJson(Files.readString(file),JsonObject.class);
        String id=value.get("id").getAsString(),action=value.get("action").getAsString();
        if(value.get("version").getAsInt()!=1||!value.get("instance").getAsString().equals(instance)||!value.get("source").getAsString().equals("pycharm")||!List.of("run","chooseRun","test","stop").contains(action)||Math.abs(System.currentTimeMillis()-value.get("sentAt").getAsLong())>15000) {Files.deleteIfExists(file);continue;}
        UUID.fromString(id);Files.deleteIfExists(file);if(!seen.add(id))continue;
        ApplicationManager.getApplication().invokeLater(()->{
          if(disposed||project.isDisposed())return;
          try {command(action);write("acks",id,Map.of("version",1,"id",id,"ok",true));}
          catch(Exception error){try{write("acks",id,Map.of("version",1,"id",id,"ok",false,"error",error.getClass().getSimpleName()));}catch(Exception ignored){}}
        });
        } catch(Exception invalid) {Files.deleteIfExists(file);}
      }
    } catch(Exception ignored){}
  }
  private void command(String action) {
    if(action.equals("stop")) {
      List<ProcessHandler> handlers; synchronized(this){handlers=new ArrayList<>(active.values());}
      if(handlers.isEmpty())return;
      if(Messages.showYesNoDialog(project,"Stop the "+handlers.size()+" running process(es) in this project?","Forever Young",Messages.getQuestionIcon())==Messages.YES)handlers.forEach(ProcessHandler::destroyProcess);
      return;
    }
    RunManager manager=RunManager.getInstance(project);
    List<RunnerAndConfigurationSettings> configs=manager.getAllSettings();
    if(action.equals("test"))configs=configs.stream().filter(c->c.getType().getId().toLowerCase(Locale.ROOT).contains("test")).toList();
    if(configs.isEmpty()){Messages.showInfoMessage(project,"Create a saved Run/Debug configuration first.","Forever Young");return;}
    PropertiesComponent preferences=PropertiesComponent.getInstance(project);
    String preference="ForeverYoung.target."+(action.equals("test")?"test":"run");
    String saved=preferences.getValue(preference);
    RunnerAndConfigurationSettings selected=action.equals("chooseRun")?null:configs.stream().filter(c->c.getUniqueID().equals(saved)).findFirst().orElse(null);
    if(selected==null&&saved==null&&!action.equals("chooseRun")) {
      RunnerAndConfigurationSettings current=manager.getSelectedConfiguration();
      selected=configs.contains(current)?current:configs.size()==1?configs.get(0):null;
    }
    if(selected==null) {
      JBPopupFactory.getInstance().createPopupChooserBuilder(configs)
        .setTitle("Forever Young · Select run target")
        .setRequestFocus(true)
        .setRenderer((list,value,index,isSelected,hasFocus)->new DefaultListCellRenderer().getListCellRendererComponent(list,value.getName(),index,isSelected,hasFocus))
        .setNamerForFiltering(RunnerAndConfigurationSettings::getName)
        .setItemChosenCallback(choice->executeSelected(action,preference,choice))
        .createPopup().showCenteredInCurrentWindow(project);
      return;
    }
    executeSelected(action,preference,selected);
  }
  private void executeSelected(String action,String preference,RunnerAndConfigurationSettings selected) {
    if(disposed||project.isDisposed())return;
    PropertiesComponent.getInstance(project).setValue(preference,selected.getUniqueID());
    if(action.equals("chooseRun"))return;
    ProgramRunnerUtil.executeConfiguration(selected,DefaultRunExecutor.getRunExecutorInstance());
  }
  @Override public synchronized void dispose(){disposed=true;timer.shutdownNow();try{Files.deleteIfExists(root.resolve("events").resolve(instance+".json"));}catch(Exception ignored){}synchronized(PetBridge.class){INSTANCES.remove(project);}}
}
